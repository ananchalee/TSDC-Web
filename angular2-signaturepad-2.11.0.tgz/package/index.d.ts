export declare class SignaturePadModule {
}
