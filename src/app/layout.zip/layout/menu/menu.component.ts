import { Component, OnInit,Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {
  @Input() Pageactive: any ;


  page:any = {}
  USER: any = {};

  constructor(private router: Router,) { }

  ngOnInit(): void {
  this.Menu();
  //console.log(this.Pageactive)

  }

  

  Menu(){  
    
    if(!this.Pageactive){

    }else{
      const user = JSON.parse(localStorage.getItem('currentUser') || '');
        //console.log(user)
       this.USER.user_firstname = user.FIRSTNAME,
       this.USER.user_lastname = user.LASTNAME,
       this.USER.worker_id = user.WORKER_ID

      if(this.Pageactive[0].pagename == 'Dashboard'){
        this.page.dashboard = this.Pageactive[0].active
      }
      else if(this.Pageactive[0].pagename == 'Check Order'||this.Pageactive[0].pagename == 'Check fullcarton' 
              ||this.Pageactive[0].pagename == 'Check Confrim Bill'){
        this.page.audit = this.Pageactive[0].active
      }else if (this.Pageactive[0].pagename == 'แก้ไขขนาดกล่อง'){
        this.page.EditBox = this.Pageactive[0].active
      }
      else if(this.Pageactive[0].pagename == 'เช็คสินค้า&ปริ้น(แบบเก่า)'||this.Pageactive[0].pagename == '' 
              ||this.Pageactive[0].pagename == ''){
        this.page.audit_Old = this.Pageactive[0].active
      }
    }
  }

  dashboard(){
    this.router.navigate(["/dashboard"]);
  }
  
  CheckOrder(){
    this.router.navigate(["/audit-check"]);
  }

  Checkfullcarton(){
    this.router.navigate(["/audit-check-fullcarton"]);
  }

  EditBox(){
    this.router.navigate(["/edit-box"]);
  }

  OldCheckOrder_Print(){
    console.log('old')
    this.router.navigate(["/audit-check-Print-Old"]);
  }



   


}
