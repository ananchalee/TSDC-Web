import { Injectable, ErrorHandler } from '@angular/core';
//import { Http, RequestOptions, ResponseContentType, Response } from '@angular/http';
import { Observable,throwError } from 'rxjs';
import { catchError,map } from 'rxjs/operators';
//import 'rxjs/add/operator/map'
import { HttpClient,HttpHeaders,HttpErrorResponse } from '@angular/common/http';
//import { errorHandler } from '@angular/platform-browser/src/browser';
//import { error } from 'util';


@Injectable()
export class DataService {



  constructor(private http: HttpClient) { }

    
  login_(data:any){
    //console.log(data)
  return this.http.post('http://10.26.1.21:1661/api/login',data);
 }

LOAD_USERTABLECHECK(data:any) {
   //console.log(data)
  return this.http.post('http://10.26.1.21:1661/api/LOAD_USERTABLECHECK', data)
}

insert_user_tablecheck(data:any){
  return this.http.post('http://10.26.1.21:1661/api/insert_user_tablecheck', data)
}

CheckWork_V2(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckWork_V2',data)
    
}

CheckCon(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckCon',data)

}

CheckConOnline(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckConOnline',data)
   
}

CheckConSorter(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckConSorter',data)
}

summaryCon(data:any){
  return this.http.post('http://10.26.1.21:1661/api/summaryCon',data)

}

summaryConSorter(data:any){
  return this.http.post('http://10.26.1.21:1661/api/summaryConSorter',data)
    
}

matchItemInCon(data:any){
  return this.http.post('http://10.26.1.21:1661/api/matchItemInCon',data)
}

matchItemInConSorter(data:any){
  return this.http.post('http://10.26.1.21:1661/api/matchItemInConSorter',data)
}

checkEqualCon(data:any){
  return this.http.post('http://10.26.1.21:1661/api/checkEqualCon',data)
    
}

checkEqualConSorter(data:any){
  return this.http.post('http://10.26.1.21:1661/api/checkEqualConSorter',data)

}

updateConQtyCheck(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateConQtyCheck',data)
}

updateConQtyCheck_SORTER(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateConQtyCheck_SORTER',data)
}


BOX_CONTROL_DETAIL(data:any){
  return this.http.post('http://10.26.1.21:1661/api/BOX_CONTROL_DETAIL',data)
}

check_master_box(data:any){
  return this.http.post('http://10.26.1.21:1661/api/check_master_box',data)
}


tsdc_pick_vas(){
  return this.http.get('http://10.26.1.21:1661/api/tsdc_pick_vas')
}

tracksum_qty(data:any){
  return this.http.post('http://10.26.1.21:1661/api/tracksum_qty',data)
}

tracking_running(data:any){
  return this.http.post('http://10.26.1.21:1661/api/tracking_running',data)
}


loadTracking(data:any){
  return this.http.post('http://10.26.1.21:1661/api/loadTracking',data)

}

CheckConOffline(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckConOffline',data)
   
}

CheckWork(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckWork',data)
   
}

summary_ITEM_LACK(data:any) {
  return this.http.post('http://10.26.1.21:1661/api/summary_ITEM_LACK', data)
   
}


summary_ITEM_LACK_SORTER(data:any) {
  return this.http.post('http://10.26.1.21:1661/api/summary_ITEM_LACK_SORTER', data)
   
}


updateConQtyCheck_fullcarton(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateConQtyCheck_fullcarton',data)
}

updateConQtyCheck_SORTER_fullcarton(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateConQtyCheck_SORTER_fullcarton',data)
}

BOX_CONTROL_DETAIL_FULLCARTON(data:any){
  return this.http.post('http://10.26.1.21:1661/api/BOX_CONTROL_DETAIL_FULLCARTON',data)
}

updateCoverSheet(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateCoverSheet',data)

}

CheckCon_Orderconfirm(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckCon_Orderconfirm',data)

}

Rescan_checkitem(data:any){
  return this.http.post('http://10.26.1.21:1661/api/Rescan_checkitem',data)

}

checkstatusUpdateConfirmOrder(data:any){
  return this.http.post('http://10.26.1.21:1661/api/checkstatusUpdateConfirmOrder',data)

}

UpdateConfirmOrder(data:any){
  return this.http.post('http://10.26.1.21:1661/api/UpdateConfirmOrder',data)

}

Rescancheckitem_all(data:any){
  return this.http.post('http://10.26.1.21:1661/api/Rescancheckitem_all',data)

}

UpdateCheckdate(data:any){
  return this.http.post('http://10.26.1.21:1661/api/UpdateCheckdate',data)

}

UpdateCheckdateSorter(data:any){
  return this.http.post('http://10.26.1.21:1661/api/UpdateCheckdateSorter',data)

}

ReprintTracking(data:any){
  return this.http.post('http://10.26.1.21:1661/api/ReprintTracking',data)
}

outstanding_online(){
  return this.http.get('http://10.26.1.21:1661/api/outstanding_online')

}
outstanding_offline(){
  return this.http.get('http://10.26.1.21:1661/api/outstanding_offline')
}

outstanding_sorter(){
  return this.http.get('http://10.26.1.21:1661/api/outstanding_sorter')
}

outstanding_CfOrder(){
  return this.http.get('http://10.26.1.21:1661/api/outstanding_CfOrder')
}
Order_disappear(){
  return this.http.get('http://10.26.1.21:1661/api/Order_disappear')
}

Order_disappear_detail(data:any){
  return this.http.post('http://10.26.1.21:1661/api/Order_disappear_detail',data)
}

percent_online(){
  return this.http.get('http://10.26.1.21:1661/api/percent_online')
}
percent_offline(){
  return this.http.get('http://10.26.1.21:1661/api/percent_offline')
}

percent_sorter(){
  return this.http.get('http://10.26.1.21:1661/api/percent_sorter')
}

percent_CForder(){
  return this.http.get('http://10.26.1.21:1661/api/percent_CForder')
}

CheckTrack(data:any){
  return this.http.post('http://10.26.1.21:1661/api/CheckTrack',data)
   
}

updateBoxTracking(data:any){
  return this.http.post('http://10.26.1.21:1661/api/updateBoxTracking',data)
}


//////////////////////// Check Old ///////
CheckWork_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/CheckWork_Old',data)
}
CheckCon_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/CheckCon_Old',data)
}
CheckConOnline_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/CheckConOnline_Old',data)
}
CheckConSorter_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/CheckConSorter_Old',data)
}
summaryCon_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/summaryCon_Old',data)
}
summaryConSorter_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/summaryConSorter_Old',data)
}
matchItemInCon_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/matchItemInCon_Old',data)
}
matchItemInConSORTER_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/matchItemInCon_Old',data)
}
checkEqualCon_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/checkEqualCon_Old',data)
}
checkEqualConSorter_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/checkEqualConSorter_Old',data)
}
tracksum_qty_Sorter_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/tracksum_qty_Sorter_Old',data)
}
updateConQtyCheck_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/updateConQtyCheck_Old',data)
}
loaddataToOut(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/loaddataToOut',data)
}
UPDATE_CARTON_PRINT(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/UPDATE_CARTON_PRINT',data)
}
summary_ITEM_LACK_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/summary_ITEM_LACK_Old',data)
}
summary_ITEM_LACK_SORTER_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/summary_ITEM_LACK_SORTER_Old',data)
}
Rescan_checkitem_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/Rescan_checkitem_Old',data)
}
Rescan_checkitem_Sorter_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/Rescan_checkitem_Sorter_Old',data)
}
tracksum_qty_Old(data:any){
  return this.http.post('http://10.26.1.21:1665/api2/tracksum_qty_Old',data)
}
}





