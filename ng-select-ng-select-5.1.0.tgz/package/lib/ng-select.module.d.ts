export declare class NgSelectModule {
}
